import numpy as np
import random as rd
import pandas as pd
import os

from abc import abstractmethod
class Pokemon:
    def __init__(self, nom, type1, type2, barreDeVie, attack, defense):
        """
        Initialise la classe Pokemon

        Parameters
        ----------
        nom : TYPE : string
            DESCRIPTION : nom du pokémon
        type1 : TYPE : string
            DESCRIPTION : premier type du pokémon
        type2 : TYPE : string
            DESCRIPTION : deuxième type du pokémon
        barreDeVie : TYPE : int
            DESCRIPTION nombre de PV restant au pokémon
        attack : TYPE : int
            DESCRIPTION : points d'attaque du pokémon
        defense : TYPE : int
            DESCRIPTION : points de défense du pokémon

        Returns
        -------
        None.

        """
        self.type1 = type1 #le type 1 du Pokemon
        self.type2 = type2 # le type 2 du Pokemon
        self.barreDeVie = barreDeVie #son nombre de points de vie
        self.nom = nom
        self.attack = attack
        self.defense = defense
        

class PokemonSauvage(Pokemon):
    def __init__(self, nom, Coord, type1, type2, barreDeVie, attack, defense):
        
        """
        Initialise la classe PokemonSauvage

        Parameters
        ----------
        nom : TYPE : string
            DESCRIPTION : nom du pokémon sauvage
        Coord : TYPE : float list
            DESCRIPTION : coordonnées de l'emplacement où se trouve le pokémon
        type1 : TYPE : string
            DESCRIPTION : premier type du pokémon sauvage
        type2 : TYPE : string
            DESCRIPTION : deuxième type du pokémon sauvage
        barreDeVie : TYPE : int
            DESCRIPTION : nombre de PV restants au pokémon
        attack : TYPE : int
            DESCRIPTION : nombre de points d'attaque du pokémon
        defense : TYPE : int
            DESCRIPTION : nombre de points de défense du pokémon

        Returns
        -------
        None.

        """
        self.Coord = Coord
        self.type1 = type1
        self.type2 = type2
        #il y aura 151 pokemons distincts donc
        #le nom peut-être la clé primaire
        #pour identifier l'instance Pokemon sauvage
        #au cours du jeu
        self.nom = nom
        self.barreDeVie = barreDeVie
        self.attack = attack
        self.defense = defense
        
    
class PokemonDresseur(Pokemon):
    def __init__(self, nom, type1, type2, barreDeVie, attack, defense):
        """
        Initialise la classe PokemonDresseur

        Parameters
        ----------
        nom : TYPE : string
            DESCRIPTION : nom du pokémon
        type1 : TYPE : string
            DESCRIPTION : premier type du pokémon
        type2 : TYPE : string
            DESCRIPTION : deuxième type du pokémon
        barreDeVie : TYPE : int
            DESCRIPTION : PV restants du pokémon
        attack : TYPE : int
            DESCRIPTION : points d'attaque du pokémon
        defense : TYPE : int
            DESCRIPTION : points de défense du pokémon

        Returns
        -------
        None.

        """
        self.nom = nom
        self.type1 = type1
        self.type2 = type2
        self.barreDeVie = barreDeVie
        self.attack = attack
        self.defense = defense
        
    
    
   

class Pokemons(PokemonSauvage):
    def __init__(self):
        """
        Initialise la classe Pokemons, contenant les attributs de tous les pokémons sauvages présents sur la carte

        Returns
        -------
        None.

        """
        tableau_pokemon = pd.read_csv('pokemon_first_gen.csv')
        #on crée l'objet Pokemon dans une colonne du tableau
        self.pokemons = {}
        nomPokemon = tableau_pokemon['Name'].tolist()
        for i in range(0, 151):
            nom = tableau_pokemon['Name'][i]
            type1 = tableau_pokemon['Type 1'][i]
            type2 = tableau_pokemon['Type 2'][i]
            hp = tableau_pokemon['HP'][i]
            attack = tableau_pokemon['Attack'][i]
            defense = tableau_pokemon['Defense'][i]
            
            #erreur quand j'utilise random pour génèrer les coordonnées: affiche le pointeur, pas le résultat;
            Coord = (10, 349)

            self.pokemons[nomPokemon[i]] = PokemonSauvage(nom, Coord, type1, type2, hp, attack, defense)

    def __len__(self):
        """
        Permet d'obtenir le nombre de pokemons sauvages présents dans l'objet

        Returns
        -------
        TYPE
            DESCRIPTION.

        """
        
        return len(self.pokemons)
    
    def __str__(self):
        """
        Affiche les informations utiles du groupe de Pokemons

        Returns
        -------
        txt : TYPE
            DESCRIPTION.

        """
        
        txt = "Nous sommes les Pokemons de la "
        txt += self.nom
        txt += ". Et nous sommes " + str(len(self.pokemons))
        return txt
    
    
    def __repr__(self):
        """
        afficher les informations utiles du groupe de Pokemons
        """
        txt = "Nous sommes les Pokemons de la "
        txt += self.pokemons['Name']
        #txt += ". Et nous sommes " + len(self.pokemons)
        return txt
    
    def remove(self, nomPokemon): 
        """
        Supprimer un Pokemon sauvage lorsqu'il est capturé
        """
        if isinstance(nomPokemon, str):
            self.pokemons.pop(nomPokemon)
            #del self.pokemons[nomPokemon]
        else:
            print(str(nomPokemon.nom) + " n'est pas un pokemon.")
    
    def __getitem__(self, clePokemon):
        """
        récupèrer un Pokemon à partir de son nom (puisque chaque instance est unique)
        renvoyer diff selon type de l'entrée entre crochet
        si coord renvoyer ça, si str renvoyer ça, si type renvoyer types, 
        """
        if isinstance(clePokemon, str):
            #appel via dictionnaire
            if clePokemon in self.pokemons:
                return self.pokemons[clePokemon]
            else:
                print (str(clePokemon) + " n'est pas dans le tableau")
        else:
            print(str(clePokemon) +" n'est pas un pokemon.")

