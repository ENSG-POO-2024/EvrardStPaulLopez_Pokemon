# -*- coding: utf-8 -*-
"""
Created on Fri May  3 21:33:02 2024

@author: gaell
"""

import numpy as np
import pygame
import time
import random 
from Pokemon import *
from player_turn import *


class Combat(PokemonSauvage, PokemonDresseur) :
    def __init__(self, pokemonJoueur, pokemonSauvage) :
        
        """
        Initialisation de la classe Combat

        Parameters
        ----------
        pokemonJoueur : TYPE PokemonDresseur object
            DESCRIPTION : pokémon choisi par le joueur pour le combat
        pokemonSauvage : TYPE PokemonSauvage object
            DESCRIPTION : pokemon sauvage à capturer

        Returns
        -------
        None.

        """
        self.p1 = pokemonJoueur
        self.p2 = pokemonSauvage
        
    def coefficient_attaque(self, p1, p2) :
        
        """
        Fonction permettant de calculer le coefficient par lequel seront multipliés les dégâts de l'attaque spéciale 
        du joueur et du pokémon sauvage

        Parameters
        ----------
        p1 : TYPE : Pokemon
            DESCRIPTION : pokémon du joueur ou pokémon ennemi selon si c'est le tour de l'un ou de l'autre
        p2 : TYPE : Pokemon
            DESCRIPTION : pokémon du joueur ou pokémon ennemi selon si c'est le tour de l'un ou de l'autre

        Returns
        -------
        coeff : TYPE : float
            DESCRIPTION : coefficient d'efficacité correspondant au pokémon dont c'est le tour

        """
        
        
        # Permet de déterminer l'efficacité de l'attaque selon le ou les types de pokemon, et donc de calculer les dégâts infligés selon le type de chacun des pokemons présents dans le combat.
        # On part avec un coefficient d'efficacité de 1, qui sera multiplié selon le combat
        
        coeff = 1
        
        if p1.type1 == 'Steel' or p1.type2 == 'Steel':
            if p2.type1 == 'Water' or p2.type1 == 'Fire' or p2.type1 == 'Steel' or p2.type1 == 'Electric' or p2.type2 == 'Water' or p2.type2 == 'Fire' or p2.type2 == 'Steel' or p2.type2 == 'Electric' :
                coeff *= 0.5
            if p2.type1 == 'Ice' or p2.type1 == 'Rock' or p2.type1 == 'Fairy' or p2.type2 == 'Ice' or p2.type2 == 'Rock' or p2.type2 == 'Fairy' :
                coeff *= 2
        
        if p1.type1 == 'Fighting' or p1.type2 == 'Fighting' :
            if p2.type1 == 'Bug' or p2.type1 == 'Poison' or p2.type1 == 'Psychic' or p2.type1 == 'Flying' or p2.type1 == 'Fairy' or p2.type2 == 'Bug' or p2.type2 == 'Poison' or p2.type2 == 'Psychic' or p2.type2 == 'Flying' or p2.type2 == 'Fairy' :
                coeff *= 0.5
            if p2.type1 == 'Ghost' or p2.type2 == 'Ghost' :
                coeff *= 0
            if p2.type1 == 'Steel' or p2.type1 == 'Ice' or p2.type1 == 'Normal' or p2.type1 == 'Rock' or p2.type2 == 'Steel' or p2.type2 == 'Ice' or p2.type2 == 'Normal' or p2.type2 == 'Rock' :
                coeff *= 2
        
        if p1.type1 == 'Dragon' or p1.type2 == 'Dragon' :
            if p2.type1 == 'Steel' or p2.type2 == 'Steel' :
                coeff *= 0.5
            if p2.type1 == 'Dragon' or p2.type2 == 'Dragon' :
                coeff *= 2
            if p2.type1 == 'Fairy' or p2.type2 == 'Fairy' :
                coeff *= 0
        
        if p1.type1 == 'Water' or p1.type2 == 'Water':
            if p2.type1 == 'Dragon' or p2.type1 == 'Water' or p2.type1 == 'Grass' or p2.type2 == 'Dragon' or p2.type2 == 'Water' or p2.type2 == 'Grass' :
                coeff *= 0.5
            if p2.type1 == 'Fire' or p2.type1 == 'Rock' or p2.type1 == 'Ground' or p2.type2 == 'Fire' or p2.type2 == 'Rock' or p2.type2 == 'Ground' :
                coeff *= 2
        
        if p1.type1 == 'Electric' or p1.type2 == 'Electric' :
            if p2.type1 == 'Dragon' or p2.type1 == 'Electric' or p2.type1 ==  'Grass' or p2.type2 == 'Dragon' or p2.type2 == 'Electric' or p2.type2 ==  'Grass' :
                coeff *= 0.5
            if p2.type1 == 'Water' or p2.type1 == 'Flying' or p2.type2 == 'Water' or p2.type2 == 'Flying' :
                coeff *= 2
            if p2.type1 == 'Ground' or p2.type2 == 'Ground' :
                coeff *= 0
            
        if p1.type1 == 'Fire' or p1.type2 == 'Fire' :
            if p2.type1 == 'Steel' or p2.type1 == 'Ice' or p2.type1 == 'Bug' or p2.type1 == 'Grass' or p2.type2 == 'Steel' or p2.type2 == 'Ice' or p2.type2 == 'Bug' or p2.type2 == 'Grass' :
                coeff *= 2
            if p2.type1 == 'Dragon' or p2.type1 == 'Water' or p2.type1 == 'Fire' or p2.type1 == 'Rock' or p2.type2 == 'Dragon' or p2.type2 == 'Water' or p2.type2 == 'Fire' or p2.type2 == 'Rock' :
                coeff *= 0.5
        
        if p1.type1 == 'Fairy' or p1.type2 == 'Fairy' :
            if p2.type1 == 'Steel' or p2.type1 == 'Fire' or p2.type1 == 'Poison' or p2.type2 == 'Steel' or p2.type2 == 'Fire' or p2.type2 == 'Poison' :
                coeff *= 0.5
            if p2.type1 == 'Fighting' or p2.type1 == 'Dragon' or p2.type2 == 'Fighting' or p2.type2 == 'Dragon' :
                coeff *= 2
            
        if p1.type1 == 'Ice' or p1.type2 == 'Ice' :
            if p2.type1 == 'Steel' or p2.type1 == 'Water' or p2.type1 == 'Fire' or p2.type1 == 'Ice' or p2.type2 == 'Steel' or p2.type2 == 'Water' or p2.type2 == 'Fire' or p2.type2 == 'Ice' :
                coeff *= 0.5
            if p2.type1 == 'Dragon' or p2.type1 == 'Grass' or p2.type1 == 'Ground' or p2.type1 == 'Flying' or p2.type2 == 'Dragon' or p2.type2 == 'Grass' or p2.type2 == 'Ground' or p2.type2 == 'Flying' :
                coeff *= 2
                
        if p1.type1 == 'Bug' or p1.type2 == 'Bug' :
            if p2.type1 == 'Steel' or p2.type1 == 'Fighting' or p2.type1 == 'Fire' or p2.type1 == 'Poison' or p2.type1 == 'Ghost' or p2.type1 == 'Flying' or p2.type1 == 'Fairy' or p2.type2 == 'Steel' or p2.type2 == 'Fighting' or p2.type2 == 'Fire' or p2.type2 == 'Poison' or p2.type2 == 'Ghost' or p2.type2 == 'Flying' or self.p2.type2 == 'Fairy' :
                coeff *= 0.5
            if p2.type1 == 'Grass' or p2.type1 == 'Psychic' or p2.type2 == 'Grass' or p2.type2 == 'Psychic' :
                coeff *= 2
        
        if p1.type1 == 'Normal' or p1.type2 == 'Normal' :
            if p2.type1 == 'Steel' or p2.type1 == 'Rock' or p2.type2 == 'Steel' or p2.type2 == 'Rock' :
                coeff *= 0.5
            if p2.type1 == 'Ghost' or p2.type2 == 'Ghost' :
                coeff *= 0
        
        if p1.type1 == 'Grass' or p1.type2 == 'Grass' :
            if p2.type1 == 'Steel' or p2.type1 == 'Dragon' or p2.type1 == 'Fire' or p2.type1 == 'Bug' or p2.type1 == 'Grass' or p2.type1 == 'Poison' or p2.type1 == 'Flying' or p2.type2 == 'Steel' or p2.type2 == 'Dragon' or p2.type2 == 'Fire' or p2.type2 == 'Bug' or p2.type2 == 'Grass' or p2.type2 == 'Poison' or p2.type2 == 'Flying' :
                coeff *= 0.5
            if p2.type1 == 'Water' or p2.type1 == 'Rock' or p2.type1 == 'Ground' or p2.type2 == 'Water' or p2.type2 == 'Rock' or p2.type2 == 'Ground' :
                coeff *= 2
        
        if p1.type1 == 'Poison' or p1.type2 == 'Poison' :
            if p2.type1 == 'Steel' or p2.type2 == 'Steel' : 
                coeff *= 0
            if p2.type1 == 'Grass' or p2.type1 == 'Fairy' or p2.type2 == 'Grass' or p2.type2 == 'Fairy' :
                coeff *= 2
            if p2.type1 == 'Poison' or p2.type1 == 'Rock' or p2.type1 == 'Soil' or p2.type1 == 'Ghost' or p2.type2 == 'Poison' or p2.type2 == 'Rock' or p2.type2 == 'Soil' or p2.type2 == 'Ghost' :
                coeff *= 0.5
            
        if p1.type1 == 'Psychic' or p1.type2 == 'Psychic' :
            if p2.type1 == 'Steel' or p2.type1 == 'Psychic' or p2.type2 == 'Steel' or p2.type2 == 'Psychic' :
                coeff *= 0.5
            if p2.type1 == 'Fighting' or p2.type1 == 'Poison' or p2.type2 == 'Fighting' or p2.type2 == 'Poison' :
                coeff *= 2
            
        if p1.type1 == 'Rock' or p1.type2 == 'Rock' :
            if p2.type1 == 'Steel' or p2.type1 == 'Fighting' or p2.type1 == 'Ground' or p2.type2 == 'Steel' or p2.type2 == 'Fighting' or p2.type2 == 'Ground' :
                coeff *= 0.5
            if p2.type1 == 'Fire' or p2.type1 == 'Ice' or p2.type1 == 'Bug' or p2.type1 == 'Flying' or p2.type2 == 'Fire' or p2.type2 == 'Ice' or p2.type2 == 'Bug' or p2.type2 == 'Flying' :
                coeff *= 2
            
        if p1.type1 == 'Ground' or p1.type2 == 'Ground' :
            if p2.type1 == 'Steel' or p2.type1 == 'Fire' or p2.type1 == 'Electric' or p2.type1 == 'Poison' or p2.type1 == 'Rock' or p2.type2 == 'Steel' or p2.type2 == 'Fire' or p2.type2 == 'Electric' or p2.type2 == 'Poison' or p2.type2 == 'Rock' :
                coeff *= 2
            if p2.type1 == 'Bug' or p2.type1 == 'Grass' or p2.type2 == 'Bug' or p2.type2 == 'Grass' :
                coeff *= 0.5
            
        if p1.type1 == 'Ghost' or p1.type2 == 'Ghost' : 
            if p2.type1 == 'Normal' or p2.type2 == 'Normal' :
                coeff *= 0
            if p2.type1 == 'Psychic' or p2.type1 == 'Ghost' or p2.type2 == 'Psychic' or p2.type2 == 'Ghost' :
                coeff *= 2
            
        if p1.type1 == 'Flying' or p1.type2 == 'Flying' :
            if p2.type1 == 'Steel' or p2.type1 == 'Electric' or p2.type1 == 'Rock' or p2.type2 == 'Steel' or p2.type2 == 'Electric' or p2.type2 == 'Rock' :
                coeff *= 0.5
            if p2.type1 == 'Fighting' or p2.type1 == 'Bug' or p2.type1 == 'Grass' or p2.type2 == 'Fighting' or p2.type2 == 'Bug' or p2.type2 == 'Grass' :
                coeff *= 2
            
        return coeff
    
    def calcul_degats(self, p1, p2, type_attaque) :
        
        """
        Permet de calculer les dégâts du joueur sur le pokémon sauvage

        Parameters
        ----------
        p1 : PokemonDresseur object
            DESCRIPTION : pokémon choisi par le joueur pour le combat
        p2 : TYPE : PokemonSauvage object
            DESCRIPTION : pokémon ennemi
        type_attaque : string
            DESCRIPTION : soit 'Attaque neutre', soit 'Attaque spéciale' selon l'attaque que le joueur a choisie

        Returns
        -------
        degats : TYPE : int
            DESCRIPTION : dégâts infligés par le joueur à l'ennemi

        """
        # On récupère les attributs qui nous intéressent des deux pokémons        
        defense_adverse = p2.defense
        
        # On différencie les deux types d'attaque pour calculer les dégâts
        if type_attaque == 'Attaque spéciale' :
            attaque = self.p1.attack * self.coefficient_attaque(self.p1, self.p2)
        else :
            attaque = self.p1.attack
        
        # Si l'action décidée par le joueur est une attaque neutre, on considère coeff = 1
        
        degats = np.ceil((attaque * 8) / defense_adverse)
        # TLe calcul des dégâts s'inspire d'une formule trouvée sur Wikipédia 
         
        return degats
     
    def calcul_degats_sur_joueur(self, p1, p2, type_attaque) :
        
        """
        Permet de calculer les dégâts du pokémon sauvage sur le joueur

        Parameters
        ----------
        p1 : TYPE : PokemonSauvage object
            DESCRIPTION : pokémon ennemi
        p2 : TYPE : PokemonDresseur object
            DESCRIPTION : pokémon choisi par le joueur pour le combat
        type_attaque : TYPE : string
            DESCRIPTION : soit 'Attaque neutre', soit 'Attaque spéciale' avec 30% de chances de tomber sur l'attaque
            spéciale contre 70% pour l'attaque neutre.

        Returns
        -------
        degats : TYPE : int
            DESCRIPTION : dégâts infligés par l'ennemi au joueur

        """
        
        # On récupère les attributs qui nous intéressent des deux pokémons        
        defense_adverse = self.p1.defense
        
        if type_attaque == 'Attaque spéciale' :
            attaque = self.p2.attack * self.coefficient_attaque(self.p2, self.p1)
        else :
            attaque = self.p2.attack
        
        # Si l'action décidée par le joueur est une attaque neutre, on considère coeff = 1
        
        degats = np.ceil((attaque * 8) / defense_adverse)
         
        return degats
    
                
                 
    def action_pokemon_sauvage(self) :
        
        """
        Permet de joueur le tour du pokémon sauvage, donc de le faire attaquer le joueur.

        Returns
        -------
        None.

        """
        
        
        # Le pokemon adverse a aussi une attaque neutre et une attaque spéciale, il choisit au hasard parmi les deux.
        
        type_attaque = random.random()
        
        # Si type_attaque > 0.7 attaque spéciale sinon attaque neutre
         
        if type_attaque > 0.7 :
            if self.p1.barreDeVie - self.calcul_degats_sur_joueur(self.p2, self.p1, 'Attaque spéciale') >= 0 :
                self.p1.barreDeVie -= self.calcul_degats_sur_joueur(self.p2, self.p1, 'Attaque spéciale')
                print(self.p2.nom, " utilise Attaque spéciale et inflige ", self.calcul_degats_sur_joueur(self.p2, self.p1, 'Attaque spéciale'), " de dégâts ! ")

            else :
                self.p1.barreDeVie = 0 # On évite d'avoir un nombre de PV négatifs
        else :
            if self.p1.barreDeVie - self.calcul_degats_sur_joueur(self.p2, self.p1, 'Attaque neutre') >= 0 :
                self.p1.barreDeVie -= self.calcul_degats_sur_joueur(self.p2, self.p1, 'Attaque neutre')
                print(self.p2.nom, " utilise Attaque neutre et inflige ", self.calcul_degats_sur_joueur(self.p2, self.p1, 'Attaque neutre'), " de dégâts ! ")

            else :
                self.p1.barreDeVie = 0
        
            
    def attaque_speciale(self) :
        """
        Permet de mettre à jour les PV de l'ennemi après que le joueur ait lancé une attaque spéciale

        Returns
        -------
        None.

        """
        if (self.p2.barreDeVie - self.calcul_degats(self.p1, self.p2, 'Attaque spéciale')) >= 0 :
            self.p2.barreDeVie -= self.calcul_degats(self.p1, self.p2, 'Attaque spéciale')
            print(self.p1.nom, "utlise Attaque spéciale et inflige ", self.calcul_degats(self.p1, self.p2, 'Attaque spéciale'), " de dégâts ! ")
        else :
            self.p2.barreDeVie = 0

    def attaque_neutre(self) :
        """
        Permet de mettre à jour les PV de l'ennemi après que le joueur ait lancé une attaque neutre

        Returns
        -------
        None.

        """
        if (self.p2.barreDeVie - self.calcul_degats(self.p1, self.p2, 'Attaque neutre')) >= 0 :
            self.p2.barreDeVie -= self.calcul_degats(self.p1, self.p2, 'Attaque neutre')
            print(self.p1.nom, "utilise Attaque neutre et inflige ", self.calcul_degats(self.p1, self.p2, 'Attaque neutre'), " de dégâts ! ")

        else :
            self.p2.barreDeVie = 0 
         
    def lancement_combat(self) :
        """
        Fait appel à la fenêtre graphique permettant au joueur de jouer le combat

        Returns
        -------
        None.

        """
        
        pygame.init() # On initialise le module permettant de jouer de la musique dans la fenêtre de combat

        ost = pygame.mixer.Sound('music/ost_fight.mp3') # On va chercher la musique à jouer dans nos fichiers

        ost.play() # On lance la musique
        
        app = QApplication(sys.argv) # Initialisation de l'environnement
        dialog = QDialog() 
        ui = Ui_Dialog_player_turn() 
        ui.setupUi(dialog, self.p1, self.p2, self) # Initialise la fenêtre de combat
        ui.ButtonResponse() # Permet au joueur d'interagir avec les boutons
        dialog.show() # Affiche la fenêtre
        
         
        sys.exit(app.exec_()) # Met fin à la fonction

