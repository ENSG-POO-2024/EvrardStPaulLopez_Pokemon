# -*- coding: utf-8 -*-
"""
Created on Tue May  7 12:19:02 2024

@author: Formation
"""
import praujetPaumemonne
import sys
from PyQt5 import QtCore, QtGui, QtWidgets
from PyQt5.QtWidgets import QWidget, QLabel,QMainWindow,QApplication,QDialog
from PyQt5.QtGui import QMovie
from PyQt5.QtCore import Qt
from carte import Ui_Dialog
DEPLACEMENT_LENT = 3
RIGHT = True
LEFT = False

class Personnage(QWidget):
    def __init__(self, xDeBase, yDeBase, direction):
        super().__init__()
        self.m_x = xDeBase
        self.m_y = yDeBase
        self.m_direction = direction
        self.Loading()

        if self.m_direction == RIGHT:
            self.m_labelMovie.setMovie(self.m_animStanceNormal_R)
        elif self.m_direction == LEFT:
            self.m_labelMovie.setMovie(self.m_animStanceNormal_L)

        self.m_labelMovie.move(self.m_x, self.m_y)

    def Loading(self):
        self.m_labelMovie = QLabel(self)
        self.m_animWalk_R = QMovie(self.m_labelMovie)
        self.m_animWalk_R.setFileName("egg.png")
        self.m_animWalk_R.start()
        self.m_animWalk_L = QMovie(self.m_labelMovie)
        self.m_animWalk_L.setFileName("egg.png")
        self.m_animWalk_L.start()
        self.m_animStance_R = QMovie(self.m_labelMovie)
        self.m_animStance_R.setFileName("egg.png")
        self.m_animStance_R.start()
        self.m_animStance_L = QMovie(self.m_labelMovie)
        self.m_animStance_L.setFileName("egg.png")
        self.m_animStance_L.start()

    def keyPressEvent(self, event):
        if event.key() == Qt.Key_Right:
            self.m_direction = RIGHT
            self.Walk()
        elif event.key() == Qt.Key_Left:
            self.m_direction = LEFT
            self.Walk()

    def keyReleaseEvent(self, event):
        self.Stance()

    def Walk(self):
        if self.m_direction == RIGHT:
            self.m_labelMovie.resize(self.m_animWalk_R.frameRect().size())
            self.m_labelMovie.setMovie(self.m_animWalk_R)
            self.m_x += DEPLACEMENT_LENT
            self.m_labelMovie.move(self.m_x, self.m_y)
        elif self.m_direction == LEFT:
            self.m_labelMovie.resize(self.m_animWalk_L.frameRect().size())
            self.m_labelMovie.setMovie(self.m_animWalk_L)
            self.m_x -= DEPLACEMENT_LENT
            self.m_labelMovie.move(self.m_x, self.m_y)

    def Stance(self):
        if self.m_direction == RIGHT:
            self.m_labelMovie.resize(self.m_animStance_R.frameRect().size())
            self.m_labelMovie.setMovie(self.m_animStance_R)
        elif self.m_direction == LEFT:
            self.m_labelMovie.resize(self.m_animStance_L.frameRect().size())
            self.m_labelMovie.setMovie(self.m_animStance_L)


if __name__=="__main__":
    def run_app():
        app = QApplication(sys.argv)
        dialog = QDialog()
        ui = Ui_Dialog()
        ui.setupUi(dialog)
        dialog.show()
        sys.exit(app.exec_())

    run_app()
    Personnage(500,-100,"LEFT").Walk() #RAJOUTER LA CLASSE PERSONNAGE DIRECTEMENT A LA CLASSE DRESSEUR, comment lier le déplacement à l'image du dresseur?